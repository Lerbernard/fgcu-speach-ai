# FGCU Engineering Course Schedule — Fall 2026 — EES

Term: Fall 2026
Subject: EES
Courses: 1

---

## EES Courses — Fall 2026

EES 3204C Fall 2026 — Instructor: Karatum, Osman
Course: Environ Chem for Engineers (3 credits) | CRN: 80576
Schedule: M W -- 10:30am - 12:45pm -- Holmes Engineering 434 M W -- 10:30am - 12:45pm -- Holmes Engineering 439 Exam : M -- 10:00am - 12:15pm -- Holmes Engineering 439
Session: Full Term
