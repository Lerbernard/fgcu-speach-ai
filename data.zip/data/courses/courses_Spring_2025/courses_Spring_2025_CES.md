# FGCU Engineering Course Schedule — Spring 2025 — CES

Term: Spring 2025
Subject: CES
Courses: 2

---

## CES Courses — Spring 2025

CES 3100C Spring 2025 — Instructor: Ozdagli, Ali
Course: Structural Analysis (3 credits) | CRN: 10395
Schedule: T R -- 10:00am - 12:15pm -- Holmes Engineering 402Exam :R -- 08:15pm - 10:30pm -- Seidler Hall 127
Session: Full Term
Note: Common final exam to be held with CRN 10394 (CES 3100C) on 5/1/2023 at 8:15-10:30pm in SH 127.:

CES 3100C Spring 2025 — Instructor: Ozdagli, Ali
Course: Structural Analysis (3 credits) | CRN: 10394
Schedule: T R -- 07:30am - 09:45am -- Holmes Engineering 402 Exam : R -- 08:15pm - 10:30pm -- Seidler Hall 127
Session: Full Term
Note: Common final exam to be held with CRN 10395 (CES 3100C) on 5/1/2023 at 8:15-10:30pm in SH 127. :
